function Login({role , loading, dispatch}){
    const handleLogin = ()=>{
        dispatch({type :"LOGIN START"})

            setTimeout(()=>{
                localStorage.setItem(role +"Token","dummy_token")


                dispatch({type:"LOGIN SUCCESS"})

            },1000)
        
    }

    return(
        <div>
            <h3>{role} Login Page</h3>

            <button onClick={handleLogin} disabled={loading}>{loading ? "Loading...":"Login"}</button>
        </div>
    )
}

export default Login